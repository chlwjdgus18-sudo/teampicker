package com.teampicker.network;

import com.teampicker.PickerConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

import java.util.ArrayList;

/** 빨강/파랑 팀원을 각자 멀리 떨어진 지점으로 보내고, 그 자리를 리스폰 지점으로 지정한다. */
public final class GameStarter {
    private GameStarter() {}

    public static void start(ServerPlayer sender) {
        MinecraftServer server = sender.server;
        ServerLevel overworld = server.overworld();
        Scoreboard scoreboard = server.getScoreboard();

        int distance = PickerConfig.DISTANCE.get();
        BlockPos redPos = surface(overworld, distance, 0);
        BlockPos bluePos = surface(overworld, -distance, 0);

        int red = 0;
        int blue = 0;

        for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
            PlayerTeam team = scoreboard.getPlayersTeam(p.getScoreboardName());
            if (team == null) {
                continue;
            }

            BlockPos pos;
            if (team.getName().equals("red")) {
                pos = redPos;
                red++;
            } else if (team.getName().equals("blue")) {
                pos = bluePos;
                blue++;
            } else {
                continue;
            }

            // forced = true : 침대 없이도 이 좌표가 리스폰 지점이 된다
            p.setRespawnPosition(Level.OVERWORLD, pos, 0.0F, true, false);
            p.teleportTo(overworld, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, p.getYRot(), p.getXRot());
            p.sendSystemMessage(Component.literal("게임 시작!").withStyle(ChatFormatting.GOLD));
        }

        if (red + blue == 0) {
            sender.sendSystemMessage(Component.literal("빨강/파랑 팀에 아무도 없어서 아무도 이동하지 않았습니다."));
        } else {
            sender.sendSystemMessage(Component.literal(
                    "게임 시작: 빨강 " + red + "명 → X=" + redPos.getX()
                            + ", 파랑 " + blue + "명 → X=" + bluePos.getX()));
        }
    }

    /** 해당 X, Z 지점의 지면 위 좌표를 구한다. 청크를 먼저 생성/로드한다. */
    private static BlockPos surface(ServerLevel level, int x, int z) {
        level.getChunk(x >> 4, z >> 4);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        return new BlockPos(x, y, z);
    }
}
