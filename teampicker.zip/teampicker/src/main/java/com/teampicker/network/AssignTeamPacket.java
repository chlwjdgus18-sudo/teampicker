package com.teampicker.network;

import net.minecraft.ChatFormatting;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/** 클라이언트 -> 서버: 대상 플레이어를 red / blue / none 으로 지정한다. */
public record AssignTeamPacket(UUID target, String team) {

    public static void encode(AssignTeamPacket pkt, FriendlyByteBuf buf) {
        buf.writeUUID(pkt.target());
        buf.writeUtf(pkt.team(), 16);
    }

    public static AssignTeamPacket decode(FriendlyByteBuf buf) {
        return new AssignTeamPacket(buf.readUUID(), buf.readUtf(16));
    }

    public static void handle(AssignTeamPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer sender = c.getSender();
            // 서버에서 한 번 더 OP 권한 검증 (클라이언트 신뢰 금지)
            if (sender == null || !sender.hasPermissions(2)) {
                return;
            }

            MinecraftServer server = sender.server;
            ServerPlayer target = server.getPlayerList().getPlayer(pkt.target());
            if (target == null) {
                sender.sendSystemMessage(Component.literal("그 플레이어는 더 이상 접속 중이 아닙니다."));
                Network.sendList(sender);
                return;
            }

            Scoreboard scoreboard = server.getScoreboard();
            String name = target.getScoreboardName();
            String label;

            switch (pkt.team()) {
                case "red" -> {
                    join(scoreboard, name, "red", "빨강팀", ChatFormatting.RED);
                    label = "빨강팀";
                }
                case "blue" -> {
                    join(scoreboard, name, "blue", "파랑팀", ChatFormatting.BLUE);
                    label = "파랑팀";
                }
                case "none" -> {
                    scoreboard.removePlayerFromTeam(name);
                    label = "팀 없음";
                }
                default -> {
                    return;
                }
            }

            sender.sendSystemMessage(Component.literal(name + " → " + label));
            // 갱신된 목록으로 UI 새로고침
            Network.sendList(sender);
        });
        c.setPacketHandled(true);
    }

    private static void join(Scoreboard scoreboard, String playerName, String teamId,
                             String display, ChatFormatting color) {
        PlayerTeam team = scoreboard.getPlayerTeam(teamId);
        if (team == null) {
            team = scoreboard.addPlayerTeam(teamId);
            team.setDisplayName(Component.literal(display));
            team.setColor(color);
        }
        // 이미 다른 팀에 있으면 바닐라가 알아서 기존 팀에서 빼 준다
        scoreboard.addPlayerToTeam(playerName, team);
    }
}
