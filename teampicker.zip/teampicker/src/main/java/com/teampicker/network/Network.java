package com.teampicker.network;

import com.teampicker.TeamPickerMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class Network {
    private static final String PROTOCOL = "2";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(TeamPickerMod.MODID, "main"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals
    );

    private Network() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, OpenPickerPacket.class,
                OpenPickerPacket::encode, OpenPickerPacket::decode, OpenPickerPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
        CHANNEL.registerMessage(id++, AssignTeamPacket.class,
                AssignTeamPacket::encode, AssignTeamPacket::decode, AssignTeamPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
        CHANNEL.registerMessage(id++, StartGamePacket.class,
                StartGamePacket::encode, StartGamePacket::decode, StartGamePacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_SERVER));
    }

    /** 현재 접속자 목록과 각자의 팀 정보를 해당 플레이어에게 보내 UI를 열게 한다. */
    public static void sendList(ServerPlayer to) {
        Scoreboard scoreboard = to.server.getScoreboard();
        List<OpenPickerPacket.Entry> list = new ArrayList<>();
        for (ServerPlayer p : to.server.getPlayerList().getPlayers()) {
            PlayerTeam team = scoreboard.getPlayersTeam(p.getScoreboardName());
            list.add(new OpenPickerPacket.Entry(
                    p.getUUID(),
                    p.getScoreboardName(),
                    team == null ? "" : team.getName()
            ));
        }
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> to), new OpenPickerPacket(list));
    }
}
