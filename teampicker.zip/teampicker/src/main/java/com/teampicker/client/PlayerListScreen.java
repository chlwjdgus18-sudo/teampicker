package com.teampicker.client;

import com.teampicker.network.Network;
import com.teampicker.network.OpenPickerPacket.Entry;
import com.teampicker.network.StartGamePacket;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.PlayerFaceRenderer;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/** 접속자 머리를 격자로 보여주는 화면. 머리를 누르면 팀 선택 화면으로 넘어간다. */
public class PlayerListScreen extends Screen {
    private static final int CELL_W = 70;
    private static final int CELL_H = 56;
    private static final int HEAD = 28;

    /** 새로고침(서버가 목록을 다시 보낼 때)해도 보던 페이지를 유지하기 위한 값. */
    private static int lastPage = 0;

    private final List<Entry> entries;
    private int page;
    private int cols;
    private int rows;
    private int perPage;
    private int left;
    private int top;
    private boolean startArmed;

    public PlayerListScreen(List<Entry> entries) {
        super(Component.literal("팀 지정"));
        this.entries = entries;
        this.page = lastPage;
    }

    private int pageCount() {
        return Math.max(1, (entries.size() + perPage - 1) / perPage);
    }

    @Override
    protected void init() {
        startArmed = false;
        cols = Math.max(1, (width - 20) / CELL_W);
        rows = Math.max(1, (height - 90) / CELL_H);
        perPage = cols * rows;
        left = (width - cols * CELL_W) / 2;
        top = 40;

        int pages = pageCount();
        page = Math.max(0, Math.min(page, pages - 1));
        lastPage = page;

        addRenderableWidget(Button.builder(Component.literal("닫기"), b -> onClose())
                .bounds(width / 2 - 40, height - 28, 80, 20).build());

        // 실수로 눌러서 전원이 순간이동하는 일을 막기 위해 두 번 눌러야 시작된다.
        addRenderableWidget(Button.builder(Component.literal("게임 시작"), b -> {
            if (!startArmed) {
                startArmed = true;
                b.setMessage(Component.literal("정말 시작? 한 번 더 클릭").withStyle(ChatFormatting.YELLOW));
            } else {
                Network.CHANNEL.sendToServer(new StartGamePacket());
                onClose();
            }
        }).bounds(width - 160, height - 28, 150, 20).build());

        if (pages > 1) {
            addRenderableWidget(Button.builder(Component.literal("<"), b -> {
                page = Math.max(0, page - 1);
                lastPage = page;
            }).bounds(width / 2 - 80, height - 28, 30, 20).build());
            addRenderableWidget(Button.builder(Component.literal(">"), b -> {
                page = Math.min(pageCount() - 1, page + 1);
                lastPage = page;
            }).bounds(width / 2 + 50, height - 28, 30, 20).build());
        }
    }

    private int cellIndexAt(double mx, double my) {
        if (mx < left || my < top) {
            return -1;
        }
        int col = (int) ((mx - left) / CELL_W);
        int row = (int) ((my - top) / CELL_H);
        if (col >= cols || row >= rows) {
            return -1;
        }
        int idx = page * perPage + row * cols + col;
        return idx < entries.size() ? idx : -1;
    }

    static int teamColor(String team) {
        return switch (team) {
            case "red" -> 0xFFFF5555;
            case "blue" -> 0xFF5555FF;
            case "" -> 0xFF777777;
            default -> 0xFFFFFF55;
        };
    }

    static String teamLabel(String team) {
        return switch (team) {
            case "red" -> "빨강팀";
            case "blue" -> "파랑팀";
            case "" -> "팀 없음";
            default -> team;
        };
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        g.drawCenteredString(font, title, width / 2, 12, 0xFFFFFF);
        g.drawCenteredString(font,
                "머리를 눌러 팀을 지정하세요  (" + (page + 1) + "/" + pageCount() + ")",
                width / 2, 24, 0xAAAAAA);

        int hover = cellIndexAt(mouseX, mouseY);
        int start = page * perPage;
        int end = Math.min(entries.size(), start + perPage);

        for (int i = start; i < end; i++) {
            int local = i - start;
            int x = left + (local % cols) * CELL_W;
            int y = top + (local / cols) * CELL_H;
            Entry e = entries.get(i);
            int color = teamColor(e.team());

            g.fill(x + 2, y + 2, x + CELL_W - 2, y + CELL_H - 2, i == hover ? 0x80FFFFFF : 0x40000000);
            g.renderOutline(x + 2, y + 2, CELL_W - 4, CELL_H - 4, color);

            PlayerFaceRenderer.draw(g, Skins.of(e.id()), x + (CELL_W - HEAD) / 2, y + 6, HEAD);

            String shown = font.plainSubstrByWidth(e.name(), CELL_W - 8);
            g.drawCenteredString(font, shown, x + CELL_W / 2, y + HEAD + 10, 0xFFFFFF);
            g.drawCenteredString(font, teamLabel(e.team()), x + CELL_W / 2, y + HEAD + 21, color);
        }

        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }
        if (button == 0) {
            int idx = cellIndexAt(mouseX, mouseY);
            if (idx >= 0 && minecraft != null) {
                minecraft.setScreen(new TeamSelectScreen(entries.get(idx), entries));
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
