package com.teampicker.client;

import com.teampicker.network.AssignTeamPacket;
import com.teampicker.network.Network;
import com.teampicker.network.OpenPickerPacket.Entry;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.PlayerFaceRenderer;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

/** 선택한 플레이어를 빨강/파랑 팀에 넣거나 팀에서 빼는 화면. */
public class TeamSelectScreen extends Screen {
    private final Entry target;
    private final List<Entry> entries;

    public TeamSelectScreen(Entry target, List<Entry> entries) {
        super(Component.literal("팀 선택"));
        this.target = target;
        this.entries = entries;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int y = height / 2 + 10;

        addRenderableWidget(Button.builder(
                        Component.literal("빨강팀").withStyle(ChatFormatting.RED), b -> send("red"))
                .bounds(cx - 100, y, 95, 24).build());
        addRenderableWidget(Button.builder(
                        Component.literal("파랑팀").withStyle(ChatFormatting.BLUE), b -> send("blue"))
                .bounds(cx + 5, y, 95, 24).build());
        addRenderableWidget(Button.builder(Component.literal("팀 해제"), b -> send("none"))
                .bounds(cx - 100, y + 30, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("뒤로"), b -> {
                    if (minecraft != null) {
                        minecraft.setScreen(new PlayerListScreen(entries));
                    }
                })
                .bounds(cx - 100, y + 56, 200, 20).build());
    }

    private void send(String team) {
        // 서버가 처리 후 갱신된 목록을 다시 보내 주면 목록 화면으로 자동 복귀한다.
        Network.CHANNEL.sendToServer(new AssignTeamPacket(target.id(), team));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);

        int cx = width / 2;
        int headSize = 48;
        int headY = height / 2 - 70;
        PlayerFaceRenderer.draw(g, Skins.of(target.id()), cx - headSize / 2, headY, headSize);
        g.drawCenteredString(font, target.name(), cx, headY + headSize + 6, 0xFFFFFF);
        g.drawCenteredString(font, "현재: " + PlayerListScreen.teamLabel(target.team()),
                cx, headY + headSize + 18, PlayerListScreen.teamColor(target.team()));

        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
